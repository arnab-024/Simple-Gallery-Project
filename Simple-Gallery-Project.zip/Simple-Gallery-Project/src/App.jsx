import React from "react";
import "./index.css";
import axios from "axios";
import Card from "./components/Card";

const App = () => {
  const [index, setIndex] = React.useState(1);

  const [userData, setUserData] = React.useState([]);
  const [darkMode, setDarkMode] = React.useState(true);
  const getData = async () => {
    console.log("Getting data...");
    const response = await axios.get(
      `https://picsum.photos/v2/list?page=${index}&limit=30`,
    );
    setUserData(response.data);
    console.log(response.data);
  };

  React.useEffect(function () {
    getData();
  }, [index]); //Dependency is important, otherwise it will run only once when the component is mounted

  let printUserData = (
    <h3 className="text-gray-400 text-xs font-semibold absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">Loading...</h3>
  );
  if (userData.length > 0) {
    printUserData = userData.map(function (element, index, array) {
      return (
        <div key={index} target="_blank">
          <Card element={element} />
        </div>
      );
    });
  }

  return (
    <div className={`${darkMode ? "bg-black text-white" : "bg-white text-black"} h-screen overflow-auto p-7 flex flex-col gap-5`}>
      <h1 className="font-serif text-3xl">Welcome to Picsum Photos!!</h1>
      <button onClick={() => setDarkMode(!darkMode)} className="bg-amber-400 text-sm cursor-pointer active:scale-95 text-black rounded px-4 py-2 font-semibold">
        {darkMode ? "Light Mode" : "Dark Mode"}
      </button>
      <div className="flex flex-1 flex-wrap gap-5 p-2 content-start">{printUserData}</div>
      <div className="flex justify-center items-center p-5 gap-5">
        <button className="bg-amber-400 text-sm cursor-pointer active:scale-95 text-black rounded px-4 py-2 font-semibold"
        onClick={() => {
          if(index > 1) {
            setIndex(index - 1);
            setUserData([]);
          } else {
            setIndex(1);
          }
        }}
        >
          Previous
        </button>
        <h1 className="bg-[#00ffae] flex w-fit border-2 mt-5 mb-5 border-[#5eff00] rounded-2xl p-2 text-black text-2xl">Page {index}</h1>
        <button className="bg-amber-400 text-sm cursor-pointer active:scale-95 text-black rounded px-4 py-2 font-semibold"
        onClick={() => {
          if(index < 10) {
            setIndex(index + 1);
            setUserData([]);
          } else {
            setIndex(10);
          }
        }}
        >
          Next
        </button>
      </div>
    </div>
  );
};

export default App;
