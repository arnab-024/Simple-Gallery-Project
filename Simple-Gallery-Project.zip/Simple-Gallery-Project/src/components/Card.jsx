import React from "react";

const Card = (k) => {
  return (
    <div>
      <a href={k.element.url}>
        <div className="h-40 w-44 overflow-hidden rounded-xl">
          <img
            src={k.element.download_url}
            alt=""
            className="h-full w-full object-cover"
          />
        </div>
        <h2 className="font-bold text-lg">{k.element.author}</h2>
      </a>
    </div>
  );
};

export default Card;
